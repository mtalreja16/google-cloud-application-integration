const {v1} = require('@google-cloud/pubsub');
const subClient = new v1.SubscriberClient();

exports.pullMessages = async (req, res) => {
    try {
      subscriptionNameOrId = "projects/integration-demo-364406/subscriptions/sub-inventory"
        const formattedSubscription =
            subscriptionNameOrId.indexOf('/') >= 0
                ? subscriptionNameOrId
                : subClient.subscriptionPath("integration-demo-364406", subscriptionNameOrId);
            const request = {
                subscription: formattedSubscription,
                maxMessages: 100,
            };
            // The subscriber pulls a specified number of messages.
            const [response] = await subClient.pull(request);

            // Process the messages.
            const ackIds = [];
            let messages = []
            for (const message of response.receivedMessages) {
                const messageBody = message.message.data ? Buffer.from(message.message.data, 'base64').toString() : null;
                messages.push(messageBody);
                ackIds.push(message.ackId);
            }
                      
            if (ackIds.length !== 0) {
              const ackRequest = {
                subscription: formattedSubscription,
                ackIds: ackIds,
              };

              await subClient.acknowledge(ackRequest);
            }
            var json = {
              eventParameters: {
                parameters: [
                {
                  key: "data",
                  value: {
                    stringValue: JSON.stringify(messages)
                  }    
                }
              ]
              },
              taskParameters: {
                parameters: [
                {
                  key: "data",
                  value: {
                    stringValue: "$data$"
                  }    
                }
              ]
              }
            };
      console.log(json);
      res.status(200).send(json);
      console.log('Done.');
    }
    catch (error) {
      console.error(error);
      res.status(500).send(error);
    }
};
